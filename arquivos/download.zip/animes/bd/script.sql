create database if not exists animes;
use animes;

create or replace table desenhos(
    id int primary key auto_increment,
    nome varchar(250) not null,
    genero varchar(250) not null ,
    episodios varchar(250) not null,
    lancamento date not null,
    created_at TIMESTAMP not null default CURRENT_TIMESTAMP 
) ENGINE=InnoDB DEFAULT CHARSET=latin1;



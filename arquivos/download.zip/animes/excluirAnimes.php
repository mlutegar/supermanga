<?php

require_once('repository/AnimesRepository.php');

$id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);

$msg = "";
    if(fnDeleteAnimes($id)) {
       $msg = "Sucesso ao apagar";
    } else {
        $msg = "Falha ao apagar";
    }

    # redirect para a pagina de formulario
    header("location: listagem-de-animes.php?notify={$msg}");
    exit;
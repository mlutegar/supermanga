<?php

    require_once('Connection.php');


    function fnAddAnimes($nome, $genero, $episodios, $lancamento) {

        $con = getConnection();
        
        $sql = "insert into desenhos (nome, genero, episodios, lancamento) values (:pNome, :pGenero, :pEpisodios, :pLancamento)";
        
        $stmt = $con->prepare($sql);
        $stmt->bindParam(":pNome", $nome);
        $stmt->bindParam(":pGenero", $genero);
        $stmt->bindParam(":pEpisodios", $episodios);
        $stmt->bindParam(":pLancamento", $lancamento);

       return $stmt->execute();
    }


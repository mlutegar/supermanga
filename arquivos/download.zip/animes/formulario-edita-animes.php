<?php 
    require_once('repository/AnimesRepository.php');
    $notificacao = filter_input(INPUT_GET, 'notify', FILTER_SANITIZE_URL);
    $id = filter_input(INPUT_GET, 'id', FILTER_SANITIZE_NUMBER_INT);
    $desenho = fnLocalizaDesenhosPorID($id);
?>

<!doctype html>

<html lang="pt_BR">

  <head>

    <meta charset="utf-8">

    <meta name="viewport" content="width=device-width, initial-scale=1">

    <title>Formulário Cadastro Anime</title>

    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-0evHe/X+R7YkIZDRvuzKMRqM+OrBnVFBL6DOitfPri4tjfHxaWutUpFmBp4vmVor" crossorigin="anonymous">

  </head>

  <body>

    <div class="col-6 offset-3">

        <fieldset>

            <legend>Edição de Animes</legend>

            <form action="editaAnimes.php" method="post" class="form">

                <div >

                    <input type="hidden" name="idDesenho" id="desenhoId"  value="<?= $desenho->id ?>">

                </div>

                <div class="mb-3 form-group">

                    <label for="nomeId" class="form-label">Nome</label>

                    <input type="text" name="nome" id="nomeId" class="form-control" placeholder="Informe o nome do anime" value="<?= $desenho->nome ?>">

                    <div id="helperNome" class="form-text">Informe o nome do anime</div>

                </div>

                <div class="mb-3 form-group">

                    <label for="generoId" class="form-label">Gênero</label>

                    <input type="text" name="genero" id="generoId" class="form-control" placeholder="Informe o gênero do anime" value="<?= $desenho->genero ?>">

                    <div id="helperGenero" class="form-text">Informe o gênero do anime</div>

                </div>

                <div class="mb-3 form-group">

                    <label for="episodiosId" class="form-label">Episódios</label>

                    <input type="text" name="episodios" id="episodiosId" class="form-control" placeholder="Informe os episódios do anime" value="<?= $desenho->episodios ?>">

                    <div id="helperEpisodios" class="form-text">Informe os episódios</div>

                </div>

                <div class="mb-3 form-group">

                    <label for="lancamentoId" class="form-label">Lançamento</label>

                    <input type="text" name="lancamento" id="lancamentoId" class="form-control" placeholder="Informe o lançamento do anime" value="<?= $desenho->lancamento ?>">

                    <div id="helperLancamento" class="form-text">Informe o lançamento AAAA-MM-DD</div>

                </div>

                <button type="submit" class="btn btn-dark">Enviar</button>
                <div id="notify" class="form-text text-capitalize fs-4"><?= $notificacao ?></div>

            </form>

        </fieldset>

    </div>



    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.0-beta1/dist/js/bootstrap.bundle.min.js" integrity="sha384-pprn3073KE6tl6bjs2QrFaJGz5/SUsLqktiwsUTF55Jfv3qYSDhgCecCxMW52nD2" crossorigin="anonymous"></script>

  </body>

</html>
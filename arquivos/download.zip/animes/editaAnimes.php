<?php

require_once('repository/AnimesRepository.php');

$id = filter_input(INPUT_POST, 'idDesenho', FILTER_SANITIZE_NUMBER_INT);
$nome = filter_input(INPUT_POST, 'nome', FILTER_SANITIZE_SPECIAL_CHARS);
$genero = filter_input(INPUT_POST, 'genero', FILTER_SANITIZE_SPECIAL_CHARS);
$episodios = filter_input(INPUT_POST, 'episodios', FILTER_SANITIZE_NUMBER_INT);
$lancamento = filter_input(INPUT_POST, 'lancamento', FILTER_SANITIZE_NUMBER_INT);

$msg = "";
    if(fnUpdateAnimes($id, $nome, $genero, $episodios, $lancamento)) {
       $msg = "Sucesso ao gravar";
    } else {
        $msg = "Falha na gravação";
    }

    # redirect para a pagina de formulario
    header("location: formulario-edita-animes.php?notify={$msg}&id=$id");
    exit;